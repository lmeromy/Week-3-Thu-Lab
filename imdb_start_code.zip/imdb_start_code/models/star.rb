class Star

end
